#include "hal_net.h"

#if 0
#pragma pack(1)
/* http://www.radiotap.org/ */
typedef struct {
    uint8_t it_version;
    uint8_t it_pad;
    uint16_t it_len;
    uint32_t it_present;
}ieee80211_radiotap_header;
#pragma pack()

#define WLAN_DEV      "wlan0"
#define MAX_SCAN_NUM  35
#define MAX_BUF       128
#define MAX_REV_BUF   512

static int sniffer_enabled = 0;
static pthread_t sniffer_tid = 0;
static sniffer_callback sniffer_cb = NULL;

static int run_command(const char *cmd, char *data, int len)
{
    FILE *fp;
    int ret;
    int len;

    fp = popen(cmd, "r");
    if (fp == NULL)
        return -1;

	if (data != NULL) {
        memset(data, 0, len);

        fread(data, len, 1, fp);
        len = strlen(data);
        if (data[len - 1] == '\n')
            data[len - 1] = '\0';
    }

    pclose(fp);

    return 0;
}

static void *sniffer_process(void *arg)
{
    uint8_t rev_buf[MAX_REV_BUF];
    int skip_len = 26; /* radiotap 默认长度为26 */

    int sock = socket(PF_PACKET, SOCK_RAW, htons(0x03));
    if (sock < 0)
		return NULL;

	struct ifreq ifr;
	memset(&ifr, 0x00, sizeof(ifr));
	strncpy(ifr.ifr_name, WLAN_DEV , strlen(WLAN_DEV) + 1);
	setsockopt(sock, SOL_SOCKET, SO_BINDTODEVICE, (char *)&ifr, sizeof(ifr));

    while ((sniffer_cb != NULL) && sniffer_enabled) {
        int rev_num = recvfrom(sock, rev_buf, MAX_REV_BUFFER, 0, NULL, NULL);
        ieee80211_radiotap_header *header = (ieee80211_radiotap_header *)rev_buf;
        skip_len = header->it_len;

        if (skip_len >= MAX_REV_BUF)
            continue;

        if (rev_num > skip_len) {
            sniffer_cb(rev_buf + skip_len, rev_num - skip_len);
        }
    }

    sniffer_cb = NULL;

    close(sock);
}
#endif

int hal_wifi_scan_all_ap(ap_scan_info_t **aps, uint32_t *num)
{
#if 0
    static ap_scan_info_t s_aps[MAX_SCAN_NUM];
    *aps = s_aps;
    *num = 0;

    memset(s_aps, 0, sizeof(s_aps));

    system("iwpriv wlan0 at_ss && sleep 2");

    FILE *fp = fopen("proc/wlan0/SS_Result", "r");
    if (fp == NULL)
        return -1;

    int idx = -1;
    while(1) {
        char *ret = NULL;
        uint8_t rbuf[MAX_BUF] = {0};

        ret = fgets(rbuf, MAX_BUF, fp);
        if (ret == NULL)
            break;

        char *op_ptr = &rbuf[0];

        op_ptr = strstr(op_ptr, "HwAddr");
        if (op_ptr != NULL) {
            idx++;

			/* bssid */
            int x1,x2,x3,x4,x5,x6;
            sscanf(op_ptr + strlen("HwAddr: "), "%02x%02x%02x%02x%02x%02x", &x1, &x2, &x3, &x4, &x5, &x6);
            s_aps[idx].bssid[0] = x1 & 0xFF;
            s_aps[idx].bssid[1] = x2 & 0xFF;
            s_aps[idx].bssid[2] = x3 & 0xFF;
            s_aps[idx].bssid[3] = x4 & 0xFF;
            s_aps[idx].bssid[4] = x5 & 0xFF;
            s_aps[idx].bssid[5] = x6 & 0xFF;

			/* channel */
            memset(rbuf, 0, MAX_BUF);
			ret = fgets(rbuf, MAX_BUF, fp);
			if (ret == NULL)
				break;

            op_ptr = strstr(op_ptr,"Channel");
        	if (op_ptr == NULL)
                break;

            sscanf(op_ptr + strlen("Channel: "), "%d", &(s_aps[idx].channel));

			/* ssid */
            memset(rbuf, 0, MAX_BUF);
			ret = fgets(rbuf, MAX_BUF, fp);
			if (ret == NULL)
				break;

            op_ptr = strstr(op_ptr, "SSID");
        	if (op_ptr == NULL)
                break;

            sscanf(op_ptr + strlen("SSID: "), "%s", s_aps[idx].ssid);
            s_aps[idx].s_len = strlen(s_aps[idx].ssid);
        } else {
            continue;
        }
    }
   
    if(idx == -1)
		return -1;

    *num = idx + 1;

	return 0;
#endif

	return 0;
}

int hal_wifi_scan_assigned_ap(char *ssid, ap_scan_info_t **ap)
{
#if 0
    ap_scan_info_t *aps = NULL;
    uint32_t num = 0;
    int index = 0;

	*ap = NULL;

	hal_wifi_scan_all_ap(&aps, &num)

    for(index = 0; index < num; index++) {
        if(strcmp(aps[index].ssid, ssid, aps[index].s_len) == 0) {
            *ap = aps + index;
            break;
        }
    }

    return 0;
#endif

	return 0;
}

int hal_wifi_release_ap(ap_scan_info_t *ap)
{
	return 0;
}

int hal_wifi_set_cur_channel(uint8_t channel)
{
#if 0
    printf("channel: %d\n", channel);

    char cmd[128] = {0};

    system("ifconfig wlan0 down");
    snprintf(cmd, sizeof(cmd), "iwpriv wlan0 set_mib channel=%d", channel);
    system(cmd);
    system("ifconfig wlan0 up");

    return 0;
#endif

	return 0;
}

int hal_wifi_get_cur_channel(uint8_t *channel)
{
#if 0
    char buf[MAX_BUF] = {0};

    run_command("iwpriv wlan0 get_mib channel", buf, MAX_BUF);

    char *op_ptr = &buf[0];
    
    op_ptr = strstr(op_ptr,"get_mib");
    if (op_ptr == NULL)
		return -1;
    
    sscanf(op_ptr + strlen("get_mib:"), "%d", channel);
#endif

	return 0;
}

int hal_wifi_set_sniffer(int enable, sniffer_callback cb)
{
#if 0
    if (enable) {
        printf("enable monitor mode\n");

        hal_wifi_set_work_mode(WMODE_SNIFFER);
        sniffer_cb = cb;
		sniffer_enabled = 1;
        pthread_create(&sniffer_tid, NULL, sniffer_process, NULL);
    } else {
        printf("disable monitor mode\n");

        hal_wifi_set_work_mode(WMODE_STATION);
		sniffer_enabled = 0;
        pthread_join(sniffer_thId, NULL);
    }

    return 0;
#endif

	return 0;
}

int hal_wifi_get_ip(wifi_type_t type, ip_info_t *ip)
{
	return 0;
}

int hal_wifi_get_mac(wifi_type_t type, mac_info_t *mac)
{
	return 0;
}

int hal_wifi_set_mac(wifi_type_t type, mac_info_t *mac)
{
	return 0;
}

int hal_wifi_set_work_mode(wifi_work_mode_t mode)
{
#if 0
	char cmd[256] = {0};

    switch (mode) {
        case WMODE_LOWPOWER:
            break;
        case WMODE_SNIFFER:
            snprintf(cmd, sizeof(cmd), "iwconfig %s mode Monitor", WLAN_DEV);
            break;
        case WMODE_STATION:
            snprintf(cmd, sizeof(cmd), "iwconfig %s mode Managed", WLAN_DEV);
            break;
        case WMODE_SOFTAP:
            snprintf(cmd, sizeof(cmd), "iwconfig %s mode Master", WLAN_DEV);
            break;
        case WMODE_STATIONAP:
            break;
        default:
            break;
    }

    system("ifconfig wlan0 down");
	system(cmd);
    system("ifconfig wlan0 up");

	return 0;
#endif

	return 0;
}

int hal_wifi_get_work_mode(wifi_work_mode_t *mode)
{
#if 0
    char cur_mode[32] = {0};
    char tmp[256] = {0};

    FILE *fp = popen("iwconfig "WLAN_DEV, "r");
	if (fp == NULL)
		return -1;

    while (fgets(tmp, sizeof(tmp), fp) != NULL)
    {
        char *ptr = strstr(tmp, "Mode:");
        if (ptr != NULL) {
            int x1, x2, x3, x4, x5, x6;
            sscanf(ptr + strlen("Mode:"), "%s ", cur_mode);
            break;
        }
    }
    pclose(fp);

    if (strncasecmp(cur_mode, "Managed", strlen("Managed")) == 0) {
        *mode = WMODE_STATION;
	} else if (strncasecmp(cur_mode, "Master", strlen("Master")) == 0) {
        *mode = WMODE_SOFTAP;
	} else if(strncasecmp(cur_mode, "Monitor", strlen("Monitor")) == 0) {
        *mode = WMODE_SNIFFER;
	} else {
        *mode = WMODE_STATION;
	}

    return 0;
#endif

	return 0;
}

int hal_wifi_connect_station(char *ssid, char *passwd)
{
	return 0;
}

int hal_wifi_disconnect_station(void)
{
	return 0;
}

int hal_wifi_get_station_rssi(char *rssi)
{
	return 0;
}

int hal_wifi_get_station_conn_stat(station_conn_stat_t *stat)
{
	return 0;
}

int hal_wifi_ap_start(ap_cfg_info_t *cfg)
{
	return 0;
}

int hal_wifi_ap_stop(void)
{
	return 0;
}

int hal_wifi_set_country_code(char *code)
{
	return 0;
}
