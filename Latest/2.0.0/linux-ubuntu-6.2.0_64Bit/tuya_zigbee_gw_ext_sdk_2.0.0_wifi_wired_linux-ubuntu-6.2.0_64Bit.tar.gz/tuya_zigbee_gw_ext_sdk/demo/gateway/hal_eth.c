#include "hal_net.h"

#if 0
static int run_command(const char *cmd, char *data, int len)
{
    FILE *fp;
    int ret;
    int len;

    fp = popen(cmd, "r");
    if (fp == NULL)
        return -1;

	if (data != NULL) {
        memset(data, 0, len);

        fread(data, len, 1, fp);
        len = strlen(data);
        if (data[len - 1] == '\n')
            data[len - 1] = '\0';
    }

    pclose(fp);

    return 0;
}
#endif

int hal_eth_get_ip(ip_info_t *ip)
{
#if 0
    int sock;
    char ipaddr[64];

    struct sockaddr_in *sin;
    struct ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
		return -1;

    memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, "eth0", sizeof(ifr.ifr_name) - 1);
	if(ioctl(sock, SIOCGIFADDR, &ifr) < 0) {
		close(sock);
		return -1;
	}

    sin = (struct sockaddr_in *)&ifr.ifr_addr;
    strcpy(ip->ip, inet_ntoa(sin->sin_addr)); 

    close(sock);

    return 0;
#endif

	return 0;
}

int hal_eth_link_status(int *status)
{
#if 0
	char buf[32] = {0};

	run_command("cat /proc/eth0/link_status | grep 1", buf, sizeof(buf));
	if (strlen(buf) == 0) {
		*status = 0;
	} else {
		*status = 1;
	}
#endif

	return 0;
}

int hal_eth_get_mac(mac_info_t *mac)
{
#if 0
    int sock;
    struct sockaddr_in *sin;
    struct ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
         return -1;

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, "eth0", sizeof(ifr.ifr_name) - 1);

    if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
        close(sock);
        return -1;
    }

    memcpy(mac->mac, ifr.ifr_hwaddr.sa_data, sizeof(mac->mac));

    close(sock);

	return 0;
#endif

	return 0;
}

int hal_eth_internet_status(int *status)
{
	return 0;
}
