#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "tuya_iot_gw_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "003tuyatestf7f149185"
#define AUTHKEY      "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"
#define PRODUCT_KEY  "GXxoKf27eVjA7x1c"

int iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

int iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

int iot_get_ssid_psk_cb(char *ssid, int ssid_size, char *psk, int psk_size)
{
	strncpy(ssid, "tuya_show", ssid_size);
	strncpy(psk, "12345678", psk_size);

	return 0;
}

int iot_fetch_local_log_cb(char *path, int path_len)
{
	char cmd[128] = {0};

	snprintf(path, path_len, "/tmp/log.tgz");

	snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", path);
	system(cmd);

	return 0;
}

int iot_dev_led_control_cb(unsigned int itime)
{
	printf("%d\n", itime);
	/* USER TODO */

	return 0;
}

int iot_sdk_process_upgrade_cb(char *img_file)
{
	printf("iot sdk upgrade\n");
	/* USER TODO */

	return 0;
}

void iot_sdk_process_reboot_cb(void)
{
	printf("reboot iot sdk\n");
	/* USER TODO */
}

int main(int argc, char **argv)
{
	ty_iot_attr_s iot_attr = {
		.storage_path = "./",
		.img_path = "/tmp",
		.tty_device = "/dev/ttyS1",
		.tty_baudrate = 115200,
		.eth_ifname = "br0",
		.wifi_ifname = "wlan0",
		.mode = WIFI_AP_FIRST,
		.ver = "1.0.0",
		.log_level = TY_LOG_LEVEL_DEBUG
	};

	ty_iot_cbs iot_cbs = {
		.get_uuid_authkey_cb = iot_get_uuid_authkey_cb,
		.get_product_key_cb = iot_get_product_key_cb,
		.get_ssid_psk_cb = iot_get_ssid_psk_cb,
		.dev_led_control_cb = iot_dev_led_control_cb,
		.sdk_process_upgrade_cb = iot_sdk_process_upgrade_cb,
		.sdk_process_reboot_cb = iot_sdk_process_reboot_cb,
		.fetch_local_log_cb = iot_fetch_local_log_cb,
	};

	if (tuya_iot_start(&iot_attr, &iot_cbs) != 0) {
		printf("failed to start tuya iot\n");
		return -1;
	}

	while (1) {
		sleep(10);
	}

	return 0;
}
