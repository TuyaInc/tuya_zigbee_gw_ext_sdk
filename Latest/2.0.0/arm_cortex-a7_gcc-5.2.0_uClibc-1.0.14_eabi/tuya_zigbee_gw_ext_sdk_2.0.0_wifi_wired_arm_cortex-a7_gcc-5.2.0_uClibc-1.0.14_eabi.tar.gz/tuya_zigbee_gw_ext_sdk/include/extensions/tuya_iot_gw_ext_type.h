#ifndef TUYA_IOT_GW_EXT_TYPE_H
#define TUYA_IOT_GW_EXT_TYPE_H

enum tyrpc_err_t {
	TYRPC_ERR_SUCCESS        = 0,
	TYRPC_ERR_UNKNOWN        = -1,
	TYRPC_ERR_INVAL          = -2,
	TYRPC_ERR_NOMEM          = -3,
	TYRPC_ERR_NOT_SUPPORTED  = -4,
};

typedef unsigned int   uint_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned char  byte_t;

enum {
    DEV_RESTORE_FACTORY_DEFAULTS      = 0,
    DEV_RESTORE_FACTORY_DATA_DEFAULTS = 1,
};

enum {
	DP_TYPE_BOOL   = 0,
	DP_TYPE_VALUE  = 1,
	DP_TYPE_STR    = 2,
	DP_TYPE_ENUM   = 3,
	DP_TYPE_BITMAP = 4,
};

typedef struct {
	byte_t dpid;
	byte_t type;
	union {
		int     dp_value;
		uint_t  dp_enum;
		char   *dp_str;
		int     dp_bool;
		uint_t  dp_bitmap;
	} value;
	uint_t time_stamp;
} ty_obj_dp_s;

typedef struct {
    byte_t       cmd_tp; 
    byte_t       dtt_tp;
    char        *cid; 
    char        *mb_id;
    uint_t       dps_cnt;
    ty_obj_dp_s  dps[0];
} ty_recv_obj_dp_s;

typedef struct {
	byte_t  cmd_tp;
	byte_t  dtt_tp;
	char   *cid;
	byte_t  dpid;
	char   *mb_id;
	uint_t  len;
	byte_t  data[0];
} ty_recv_raw_dp_s;

typedef struct {
	char *rule_id;
} ty_scene_linkage_attr_s;

#endif
