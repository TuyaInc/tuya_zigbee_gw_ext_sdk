#ifndef TUYA_IOT_GW_API_H
#define TUYA_IOT_GW_API_H

typedef enum {
    TY_LOG_LEVEL_ERR     = 0,
    TY_LOG_LEVEL_WARN    = 1,
    TY_LOG_LEVEL_NOTICE  = 2,
    TY_LOG_LEVEL_INFO    = 3,
    TY_LOG_LEVEL_DEBUG   = 4,
    TY_LOG_LEVEL_TRACE   = 5
} ty_log_lovel_t;

typedef enum {
	WIFI_AP_ONLY           = 0, /* only support AP mode */
	WIFI_STARTCONFIG_ONLY  = 1, /* only support SmartConfig mode */
	WIFI_AP_FIRST          = 2,
	WIFI_STARTCONFIG_FIRST = 3,
} wifi_conn_mode_t;

typedef struct {
	char *storage_path;
	char *img_path;
	char *tty_device;
	int tty_baudrate;
	char *eth_ifname;
	char *wifi_ifname;
	wifi_conn_mode_t mode;
	char *ver;
	ty_log_lovel_t log_level;
} ty_iot_attr_s;

typedef struct {
	int  (*get_uuid_authkey_cb)(char *uuid, int uuid_size, char *authkey, int authkey_size);
	int  (*get_product_key_cb)(char *pk, int pk_size);
	int  (*get_ssid_psk_cb)(char *ssid, int ssid_size, char *psk, int psk_size);
	int  (*dev_led_control_cb)(unsigned int itime); 
	int  (*sdk_process_upgrade_cb)(char *img_file);
	void (*sdk_process_reboot_cb)(void);
	int  (*fetch_local_log_cb)(char *path, int path_len);
} ty_iot_cbs;

int tuya_iot_start(ty_iot_attr_s *attr, ty_iot_cbs *cbs);

#endif
