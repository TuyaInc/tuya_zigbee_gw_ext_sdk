#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <unistd.h>
#include <string.h>

#include "tuya_iot_gw_ext_type.h"
#include "tuya_iot_gw_ext_api.h"

void print_usage(void)
{
    printf("usage:\r\n");
    printf("  o: obj dp report unittest\r\n");
    printf("  r: raw dp report unittest\r\n");
    printf("  b: bind device unittest\r\n");
    printf("  u: unbind device unittest\r\n");
    printf("  h: send heatbeat to fresh online status\r\n");
    printf("  U: unactive gateway\r\n");
    printf("  q: exit \r\n");
    printf("\r\n");
}

void device_dp_obj_exec_cb(ty_recv_obj_dp_s *dp)
{
	int i = 0;
	printf("cmd_tp: %d, dtt_tp: %d, dps_cnt: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dps_cnt);

	for (i = 0; i < dp->dps_cnt; i++) {
		printf("dpid: %d\n", dp->dps[i].dpid);
		switch (dp->dps[i].type) {
			case DP_TYPE_BOOL:
				printf("dp_bool value: %d\n", dp->dps[i].value.dp_bool);
				break;
			case DP_TYPE_VALUE:
				printf("dp_value value: %d\n", dp->dps[i].value.dp_value);
				break;
			case DP_TYPE_ENUM:
				printf("dp_enum value: %d\n", dp->dps[i].value.dp_enum);
				break;
			case DP_TYPE_STR:
				printf("dp_str value: %s\n", dp->dps[i].value.dp_str);
				break;
		}
	}

	if (dp->cid == NULL) {
		/* dps for gateway */
		/* USER TODO */
	} else {
		/* dps for subdevice */
		/* USER TODO */
	}
}

void device_dp_raw_exec_cb(ty_recv_raw_dp_s *dp)
{
	int i = 0;

	printf("cmd_tp: %d, dtt_tp: %d, dpid: %d, len: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dpid, dp->len);

	printf("raw data: ");
	for (i = 0; i < dp->len; i++) {
		printf("%02x ", dp->data[i]);
	}
	printf("\n");

	/* USER TODO */
}

void device_add_cb(const int permit, const uint_t timeout)
{
	printf("permit: %d, timeout: %d\n", permit, timeout);
	/* USER TODO */

	return;
}

void device_del_cb(const char *dev_id)
{
	printf("dev_id: %s\n", dev_id);
	/* USER TODO */
}

void device_group_ctrl_cb(int action, const char *dev_id, const char *grp_id)
{
	printf("action: %d, dev_id: %s, grp_id: %s\n", action, dev_id, grp_id);
	/* USER TODO */
}

void device_scene_ctrl_cb(int action, const char *dev_id, const char *grp_id, const char *sce_id)
{
	printf("action: %d, dev_id: %s, grp_id: %s, sce_id: %s\n", action, dev_id, grp_id, sce_id);
	/* USER TODO */
}

void device_bind_ifm_cb(const char *dev_id, const int rc)
{
	printf("dev_id: %s, result: %d\n", dev_id, rc);
	/* USER TODO */
}

void device_reset_cb(const char *dev_id, int type)
{
	printf("dev_id: %s, type: %d\n", dev_id, type);
	/* USER TODO */
}

void do_device_bind(void)
{
	uint_t uddd = 0x83000101;
	char *dev_id = "000d6ffffe67e2ca";
	char *pk = "d1xabwgg";
	char *ver = "1.0.0";

	tuya_user_iot_gw_bind_dev(uddd, dev_id, pk, ver);
}

void do_device_unbind(void)
{
	char *dev_id = "000d6ffffe67e2ca";

	tuya_user_iot_gw_unbind_dev(dev_id);
}

void do_device_heatbeat(void)
{
	char *dev_id = "000d6ffffe67e2ca";

	tuya_user_iot_fresh_dev_hb(dev_id);
}

void do_scene_linkage(void)
{
	ty_scene_linkage_attr_s attr = { .rule_id = "12345" };

	tuya_user_iot_scene_linkage_exec(&attr);
}

void do_gateway_unactive(void)
{
	tuya_user_iot_gw_unactive();
}

void do_gw_toggle_cfg(void)
{
	tuya_user_iot_gw_toggle_cfg();
}

void do_device_raw_dp_report(void)
{
	char *dev_id = "000d6ffffe67e2ca";
	byte_t dpid = 102;
	byte_t data[] = {0x1, 0x2, 0x3};
	uint_t len = sizeof(data);

	tuya_user_dev_report_dp_raw_sync(dev_id, dpid, len, data);
}

void do_device_obj_dp_report(void)
{
	int ret = 0, i = 0;
	char *dev_id = "000d6ffffe67e2ca";
	int dps_cnt = 3;
	ty_obj_dp_s *dps = NULL;

	dps = (ty_obj_dp_s *)malloc(dps_cnt * sizeof(ty_obj_dp_s));
	if (dps == NULL) {
		printf("failed to allocate memory for dp\n");
		return;
	}

	dps[0].dpid = 1;
	dps[0].type = DP_TYPE_BOOL;
	dps[0].value.dp_bool = 1;

	dps[1].dpid = 8;
	dps[1].type = DP_TYPE_STR;
	dps[1].value.dp_str = "Hello";

	dps[2].dpid = 10;
	dps[2].type = DP_TYPE_ENUM;
	dps[2].value.dp_enum = 5;

	ret = tuya_user_dev_report_dp_json_async(dev_id, dps_cnt, dps);
	if (ret != 0) {
		printf("ooops, wrong\n");
	}

	if (dps != NULL)
		free(dps);
}

int main(int argc, char **argv)
{
	int ret = 0;
    char line[256] = {0};
	void *ctx  = NULL;

	ty_gw_dev_cbs gw_dev_cbs = {
		.gw_dev_add_cb = device_add_cb,
		.gw_dev_del_cb = device_del_cb,
		.gw_dev_group_ctrl_cb = device_group_ctrl_cb,
		.gw_dev_scene_ctrl_cb = device_scene_ctrl_cb,
		.gw_dev_bind_ifm_cb = device_bind_ifm_cb 
	};

	ty_gw_cbs gw_cbs = {
		.dev_obj_dp_cb = device_dp_obj_exec_cb,
		.dev_raw_dp_cb = device_dp_raw_exec_cb,
		.dev_reset_cb = device_reset_cb
	};

	ret = tuya_user_iot_init();
	if (ret != 0) {
		printf("fail to initialize user iot\n");
		return -1;
	}

	tuya_user_iot_reg_gw_cb(&gw_cbs);
	tuya_user_iot_reg_gw_dev_cb(&gw_dev_cbs);

	print_usage();
	while (1) {
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
            case 'o':
				/* obj dp report */
				do_device_obj_dp_report();
				break;
            case 'r':
				/* raw dp report */
				do_device_raw_dp_report();
				break;
            case 'b':
				/* bind */
				do_device_bind();
				break;
            case 'u':
				/* unbind */
				do_device_unbind();
				break;
			case 'h':
				/* heartbeat */
				do_device_heatbeat();
				break;
			case 's':
				/* scene linkage */
				do_scene_linkage();
				break;
			case 'U':
				/* unactive */
				do_gateway_unactive();
				break;
			case 'c':
				do_gw_toggle_cfg();
				break;
            case 'q':
				exit(0);
				break;
            default:
				print_usage();
				break;
		}
	}

	return 0;
}

