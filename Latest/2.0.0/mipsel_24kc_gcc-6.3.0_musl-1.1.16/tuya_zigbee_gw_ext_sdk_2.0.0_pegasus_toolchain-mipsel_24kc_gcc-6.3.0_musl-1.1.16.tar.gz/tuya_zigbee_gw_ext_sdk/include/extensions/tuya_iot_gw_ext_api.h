#ifndef TUYA_IOT_GW_EXT_API_H
#define TUYA_IOT_GW_EXT_API_H

#include "tuya_iot_gw_ext_type.h"

typedef struct {
	void (*dev_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	void (*dev_raw_dp_cb)(ty_recv_raw_dp_s *dp);
	void (*dev_reset_cb)(const char *dev_id, int type);
} ty_gw_cbs;

typedef struct {
	void (*gw_dev_add_cb)(int permit, uint_t timeout);
	void (*gw_dev_del_cb)(const char *dev_id);
	void (*gw_dev_group_ctrl_cb)(int action, const char *dev_id, const char *grp_id);
	void (*gw_dev_scene_ctrl_cb)(int action, const char *dev_id, const char *grp_id, const char *sce_id);
	void (*gw_dev_bind_ifm_cb)(const char *dev_id, int result);
} ty_gw_dev_cbs;

/**
 * @brief    initiate user iot, must be called at first.
 *
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_init(void);

/**
 * @brief    register gateway callbacks.
 *
 * @param cbs.  a set of callbacks.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
void tuya_user_iot_reg_gw_cb(ty_gw_cbs *cbs);

/**
 * @brief    register device management callbacks.
 *
 * @param cbs.  a set of callbacks.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
void tuya_user_iot_reg_gw_dev_cb(ty_gw_dev_cbs *cbs);

/**
 * @brief    report obj dp to tuay cloud.
 *
 * @param dev_id.  device unique ID.
 * @param dps_cnt. dp array length.
 * @param dps.     dp array.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_dev_report_dp_json_async(const char *dev_id, uint_t dps_cnt, ty_obj_dp_s *dps);

/**
 * @brief    report raw dp to tuya cloud.
 *
 * @param dev_id. device unique ID.
 * @param dpid.   dp ID.
 * @param len.    raw data length.
 * @param dps.    raw data.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_dev_report_dp_raw_sync(const char *dev_id, uint_t dpid, uint_t len, byte_t *data);

/**
 * @brief    bind device to tuya cloud.
 *
 * @param uddd.   custom filed, the highest bit must be 1.
 * @param dev_id. device unique ID.
 * @param pid.    product ID.
 * @param ver.    device software version.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_gw_bind_dev(uint_t uddd, const char *dev_id, const char *pid, const char *ver);

/**
 * @brief    unbind device from tuya cloud.
 *
 * @param dev_id. device unique ID.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_gw_unbind_dev(const char *dev_id);

/**
 * @brief    fresh device online status.
 *
 * @param dev_id. device unique ID.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_fresh_dev_hb(const char *dev_id);

/**
 * @brief    execute scene linkage.
 *
 * @param attr. attributes of scene linkage.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_scene_linkage_exec(ty_scene_linkage_attr_s *attr);

/**
 * @brief    unactive gateway.
 *
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_gw_unactive(void);

/**
 * @brief    enable/disable long configuration mode.
 *
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_gw_toggle_cfg(void);
#endif
