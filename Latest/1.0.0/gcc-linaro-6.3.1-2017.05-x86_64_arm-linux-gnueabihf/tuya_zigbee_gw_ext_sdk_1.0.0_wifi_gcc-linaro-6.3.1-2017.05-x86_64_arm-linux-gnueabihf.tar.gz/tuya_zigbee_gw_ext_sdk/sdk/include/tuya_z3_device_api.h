#ifndef TUYA_Z3_DEVICE_API_H
#define TUYA_Z3_DEVICE_API_H

#include "tuya_iot_types.h"

#define Z3_DEV_ID_LEN    32
#define ENDPOINT_MAX     10
#define CLUSTER_LIST_MAX 10
#define MANU_NAME_LEN    32
#define MODEL_ID_LEN     32

#define Z3_PROFILE_ID_HA           0x0104

#define Z3_CMD_TYPE_GLOBAL         0x01
#define Z3_CMD_TYPE_PRIVATE        0x02
#define Z3_CMD_TYPE_ZDO            0x03

typedef struct {
	char     id[Z3_DEV_ID_LEN+1];
	uint16_t node_id;
	uint16_t profile_id[ENDPOINT_MAX];
	uint16_t device_id[ENDPOINT_MAX];
	uint16_t cluster_list[ENDPOINT_MAX][CLUSTER_LIST_MAX];
	uint8_t  endpoint[ENDPOINT_MAX];
	uint8_t  endpoint_num;
	char     manu_name[MANU_NAME_LEN+1];
	char     model_id[MODEL_ID_LEN+1];
	char     rejoin_flag;
} ty_z3_desc_s;

typedef struct {
    char id[Z3_DEV_ID_LEN+1];
    uint16_t node_id;
    uint16_t profile_id;
    uint16_t cluster_id;
    uint8_t src_endpoint;
    uint8_t dst_endpoint;
    uint16_t group_id;
    uint8_t cmd_type;
    uint8_t cmd_id;
    uint8_t frame_type;
    char disable_ack;
    uint16_t msg_length;
    uint8_t *message;
} ty_z3_aps_frame_s;

typedef struct {
    int (*z3_active_state_changed_cb)(const char *id, int state);
    int (*z3_dev_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int (*z3_dev_raw_dp_cb)(ty_recv_raw_dp_s *dp);
    int (*z3_dev_read_attr_cb)(const char *id, uint_t uddd);
    int (*z3_dev_join_cb)(ty_z3_desc_s *dev);
    int (*z3_dev_leave_cb)(const char *id);
    int (*z3_zcl_report_cb)(ty_z3_aps_frame_s *frame);
    int (*z3_all_zcl_report_cb)(ty_z3_aps_frame_s *frame);
} ty_z3_dev_cbs;

/**
 * @brief    register ZigBee3.0 device management callbacks.
 *
 * @param cbs.  a set of callbacks.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_reg_z3_dev_cb(ty_z3_dev_cbs *cbs);

/**
 * @brief    set custom device list to SDK.
 *
 * @param file.  json configuration file.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_z3_set_custom_device(const char *file);


/**
 * @brief    bind z3 device to tuya cloud.
 *
 * @param uddd.   custom filed, the highest bit must be 1.
 * @param dev_id. device unique ID.
 * @param pid.    product ID.
 * @param ver.    device software version.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_z3_dev_bind(uint_t uddd, const char *dev_id, const char *pk, const char *ver);

/**
 * @brief    send ZCL command to device.
 *
 * @param frame.  ZigBee3.0 ZCL message header and payload.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_z3_send_zcl_cmd(ty_z3_aps_frame_s *frame);

/**
 * @brief    take device off ZigBee network.
 *
 * @param id.  unique ID for device.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_z3_del_dev(const char *id);

/**
 * @brief    upgrade device firmware.
 *
 * @param id.    unique ID for device.
 * @param file.  firmare file.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_z3_upgrade_dev(const char *id, const char *file);

#endif
