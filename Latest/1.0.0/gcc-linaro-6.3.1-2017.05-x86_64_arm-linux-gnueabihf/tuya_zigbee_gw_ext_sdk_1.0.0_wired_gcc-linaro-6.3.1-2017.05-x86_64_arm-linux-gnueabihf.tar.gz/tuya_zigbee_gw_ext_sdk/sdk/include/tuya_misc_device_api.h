#ifndef TUYA_MISC_DEVICE_API_H
#define TUYA_MISC_DEVICE_API_H

#include "tuya_iot_types.h"

typedef struct {
	int (*misc_dev_add_cb)(int permit, uint_t timeout);
	int (*misc_dev_del_cb)(const char *dev_id);
	int (*misc_dev_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int (*misc_dev_raw_dp_cb)(ty_recv_raw_dp_s *dp);
	int (*misc_dev_bind_ifm_cb)(const char *dev_id, int result);
	int (*misc_dev_upgrade_cb)(const char *dev_id, const ty_fw_info_s *fw);
	int (*misc_dev_reset_cb)(const char *dev_id);
} ty_misc_dev_cbs;

typedef void (*misc_do_ug_cb)(const ty_fw_info_s *fw, int download_result, void *pri_data);
typedef int  (*misc_get_data_cb)(const ty_fw_info_s *fw, \
                                 uint_t total_len, \
							     uint_t offset, \
							     uint8_t *data, \
							     uint_t len, \
							     uint_t *remain_len, \
							     void *pri_data);					   

/**
 * @brief    register misc device management callbacks.
 *
 * @param cbs.  a set of callbacks.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_reg_misc_dev_cb(ty_misc_dev_cbs *cbs);

/**
 * @brief    bind misc device to tuya cloud.
 *
 * @param uddd.   custom filed, the highest bit must be 1.
 * @param dev_id. device unique ID.
 * @param pid.    product ID.
 * @param ver.    device software version.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_dev_bind(uint_t uddd, const char *dev_id, const char *pk, const char *ver);

/**
 * @brief    unbind misc device from tuya cloud.
 *
 * @param dev_id. device unique ID.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_unbind_dev(const char *dev_id);

/**
 * @brief    fresh misc device online status.
 *
 * @param dev_id.  device unique ID.
 * @param timeout. offline timeout, uint: seconds.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_fresh_dev_hb(const char *dev_id, uint_t timeout);

/**
 * @brief    upgrade device firmware.
 * 
 * @param dev_id.   device unique ID.
 * @param fw.       firmware information.
 * @param data_cb.  firmware data callback.
 * @param ug_cb.    upgrade callback.
 * @param pri_data. private data.
 */
int tuya_iot_misc_upgrade_notify(const char *dev_id, \
                                 const ty_fw_info_s *fw, \
								 misc_get_data_cb data_cb, \
								 misc_do_ug_cb ug_cb, \
								 void *pri_data);
#endif