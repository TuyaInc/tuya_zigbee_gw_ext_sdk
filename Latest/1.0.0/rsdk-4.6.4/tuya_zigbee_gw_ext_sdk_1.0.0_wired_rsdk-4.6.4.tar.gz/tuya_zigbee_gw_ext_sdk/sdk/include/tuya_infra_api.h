#ifndef TUYA_INFRA_API_H
#define TUYA_INFRA_API_H

#include "tuya_iot_types.h"

typedef struct {
	char *storage_path;
	char *img_path;
	char *tty_device;
	int tty_baudrate;
	char *eth_ifname;
	char *wifi_ifname;
	char *ver;
	ty_conn_mode_t wifi_mode;
	ty_log_lovel_t log_level;
} ty_gw_attr_s;

typedef struct {
	int  (*get_uuid_authkey_cb)(char *uuid, int uuid_size, char *authkey, int authkey_size);
	int  (*get_product_key_cb)(char *pk, int pk_size);
	int  (*get_ssid_psk_cb)(char *ssid, int ssid_size, char *psk, int psk_size);
	int  (*gw_upgrade_cb)(const char *img_file);
	void (*gw_reboot_cb)(void);
	void (*gw_reset_cb)(void);
	int  (*gw_fetch_local_log_cb)(char *path, int path_len);
    int  (*gw_led_control_cb)(unsigned int itime); 
    int  (*gw_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int  (*gw_raw_dp_cb)(ty_recv_raw_dp_s *dp);
	int  (*gw_active_state_changed_cb)(const char *dev_id, int state);
	int  (*gw_online_status_changed_cb)(const char *dev_id, int status);
} ty_gw_cbs;

/**
 * @brief    initiate sdk.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_init(ty_gw_attr_s *attr, ty_gw_cbs *cbs);

/**
 * @brief    report obj dp to tuay cloud.
 *
 * @param dev_id.  device unique ID.
 * @param dps.     dp array.
 * @param dps_cnt. dp array length.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_report_dp_json_async(const char *dev_id, ty_obj_dp_s *dps, uint_t dps_cnt);

/**
 * @brief    report raw dp to tuya cloud.
 *
 * @param dev_id. device unique ID.
 * @param dpid.   dp ID.
 * @param dps.    raw data.
 * @param len.    raw data length.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_report_dp_raw_sync(const char *dev_id, uint_t dpid, byte_t *data, uint_t len);

/**
 * @brief    get device online status.
 *
 * @param dev_id.  device unique ID.
 * @param status.  1: online, 0: offline.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_get_dev_online_status(const char *dev_id, int *status);

/**
 * @brief    execute scene linkage.
 *
 * @param attr. attributes of scene linkage.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_exec_scene(ty_scene_attr_s *attr);

/**
 * @brief    unactive gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_unactive_gw(void);

/**
 * @brief    active gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_active_gw(const char *token);

/**
 * @brief    allow or disallow subdevice to join network.
 *
 * @param permit. 0: disallow, 1: allow.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_permit_join(int permit);

#endif
