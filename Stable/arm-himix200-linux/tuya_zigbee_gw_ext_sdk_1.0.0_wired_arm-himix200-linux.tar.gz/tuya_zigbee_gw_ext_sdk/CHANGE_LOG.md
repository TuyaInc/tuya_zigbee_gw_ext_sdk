release note for sdk 1.0.0 20200303:

[改进与优化]
- 支持一键配网  
- 支持接入子设备  
- 支持接入ZigBee子设备  
