#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "tuya_infra_api.h"
#include "tuya_misc_device_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "003tuyatestf7f149185"
#define AUTHKEY      "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"
#define PRODUCT_KEY  "GXxoKf27eVjA7x1c"

static void print_usage(void)
{
    printf("usage:\r\n");
    printf("  o: obj dp report api unittest\r\n");
    printf("  b: bind device api unittest\r\n");
    printf("  u: unbind device api unittest\r\n");
    printf("  h: send heatbeat api unittest\r\n");
    printf("  U: unactive gw api unittest\r\n");
    printf("  p: permit join api unittest\r\n");
    printf("  q: exit \r\n");
    printf("\r\n");
}

int iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

int iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

int iot_fetch_local_log_cb(char *path, int path_len)
{
	char cmd[128] = {0};

	snprintf(path, path_len, "/tmp/log.tgz");

	snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", path);
	system(cmd);

	return 0;
}

int device_dp_obj_exec_cb(ty_recv_obj_dp_s *dp)
{
	int i = 0;
	
    printf("cmd_tp: %d, dtt_tp: %d, dps_cnt: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dps_cnt);

	for (i = 0; i < dp->dps_cnt; i++) {
		printf("dpid: %d\n", dp->dps[i].dpid);
		switch (dp->dps[i].type) {
			case DP_TYPE_BOOL:
				printf("dp_bool value: %d\n", dp->dps[i].value.dp_bool);
				break;
			case DP_TYPE_VALUE:
				printf("dp_value value: %d\n", dp->dps[i].value.dp_value);
				break;
			case DP_TYPE_ENUM:
				printf("dp_enum value: %d\n", dp->dps[i].value.dp_enum);
				break;
			case DP_TYPE_STR:
				printf("dp_str value: %s\n", dp->dps[i].value.dp_str);
				break;
		}
	}

	/* TODO */

    return 0;
}

int device_dp_raw_exec_cb(ty_recv_raw_dp_s *dp)
{
	int i = 0;

	printf("cmd_tp: %d, dtt_tp: %d, dpid: %d, len: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dpid, dp->len);

	printf("raw data: ");
	for (i = 0; i < dp->len; i++) {
		printf("%02x ", dp->data[i]);
	}
	printf("\n");

	/* USER TODO */

    return 0;
}

int device_add_cb(const int permit, const uint_t timeout)
{
	printf("permit: %d, timeout: %d\n", permit, timeout);
	
    /* USER TODO */

	return 0;
}

int device_del_cb(const char *dev_id)
{
	printf("dev_id: %s\n", dev_id);
	
    /* USER TODO */

    return 0;
}

int device_bind_ifm_cb(const char *dev_id, int result)
{
    printf("dev_id: %s, result: %d\n", dev_id, result);

	/* USER TODO */

    return 0;
}

int device_upgrade_cb(const char *dev_id, const ty_fw_info_s *fw)
{
    printf("dev_id: %s\n", dev_id);
    printf("   fw type: %d\n", fw->tp);
    printf("    fw url: %s\n", fw->fw_url);
    printf("fw version: %s\n", fw->sw_ver);

    /* USER TODO */

    return 0;
}

int device_reset_cb(const char *dev_id)
{
    printf("dev_id: %s\n", dev_id);

	/* USER TODO */

    return 0;
}

int test_device_obj_dp_report(void)
{
    static int val = 0;
	int ret = 0, i = 0;
	char *dev_id = "000d6ffffe67e2ca";
	int dps_cnt = 1;
	ty_obj_dp_s *dps = NULL;

	dps = (ty_obj_dp_s *)malloc(dps_cnt * sizeof(ty_obj_dp_s));
	if (dps == NULL) {
		printf("malloc failed\n");
		return -1;
	}

    val ^= 1;

	dps[0].dpid = 1;
	dps[0].type = DP_TYPE_BOOL;
	dps[0].value.dp_bool = val;

	ret = tuya_user_iot_report_dp_json_async(dev_id, dps, dps_cnt);
	if (ret != 0) {
		printf("tuya_user_iot_report_dp_json_async failed, ret: %d\n", ret);
        return ret;
	}

	if (dps != NULL)
		free(dps);

    return 0;
}

int test_device_bind(void)
{
    int ret = 0;
	uint_t uddd = 0x83000101;
	char *dev_id = "000d6ffffe67e2ca";
	char *pk = "d1xabwgg";
	char *ver = "1.0.0";

	ret = tuya_user_iot_misc_dev_bind(uddd, dev_id, pk, ver);
    if (ret != 0) {
        printf("tuya_user_iot_bind_dev failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

int test_device_unbind(void)
{
    int ret = 0;
	char *dev_id = "000d6ffffe67e2ca";

	ret = tuya_user_iot_misc_unbind_dev(dev_id);
    if (ret != 0) {
        printf("tuya_user_iot_unbind_dev failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

int test_device_fresh_heatbeat(void)
{
    int ret = 0;
	char *dev_id = "000d6ffffe67e2ca";

	ret = tuya_user_iot_misc_fresh_dev_hb(dev_id, 120);
    if (ret != 0) {
        printf("tuya_user_iot_fresh_dev_hb failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

int test_unactive_gw(void)
{
    int ret = 0;

    ret = tuya_user_iot_unactive_gw();
    if (ret != 0) {
        printf("tuya_user_iot_unactive_gw failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

int test_permit_join(void)
{
    int ret = 0;
    static int permit = 0;

    permit ^= 1;

    ret = tuya_user_iot_permit_join(permit);
    if (ret != 0) {
        printf("tuya_user_iot_permit_join failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

int main(int argc, char **argv)
{
    int ret = 0;
    char line[256] = {0};

    ty_gw_attr_s gw_attr = {
        .storage_path = "./",
        .cache_path = "/tmp/",
        .tty_device = "/dev/ttyS1",
        .tty_baudrate = 115200,
        .eth_ifname = "br0",
        .ver = "1.0.0",
        .log_level = TY_LOG_LEVEL_DEBUG
    };

    ty_gw_cbs gw_cbs = {
        .get_uuid_authkey_cb = iot_get_uuid_authkey_cb,
        .get_product_key_cb = iot_get_product_key_cb,
        .gw_fetch_local_log_cb = iot_fetch_local_log_cb,
    };

	ty_misc_dev_cbs misc_dev_cbs = {
        .misc_dev_add_cb = device_add_cb,
        .misc_dev_del_cb = device_del_cb,
        .misc_dev_obj_dp_cb = device_dp_obj_exec_cb,
        .misc_dev_raw_dp_cb = device_dp_raw_exec_cb,
        .misc_dev_bind_ifm_cb = device_bind_ifm_cb,
        .misc_dev_upgrade_cb = device_upgrade_cb,
        .misc_dev_reset_cb = device_reset_cb
	};

    ret = tuya_user_iot_init(&gw_attr, &gw_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_init failed\n");
        return ret;
    }

    ret = tuya_user_iot_reg_misc_dev_cb(&misc_dev_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_reg_misc_dev_cb failed\n");
        return ret;
    }

	print_usage();
	while (1) {
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
            case 'o':
				/* obj dp report */
				test_device_obj_dp_report();
				break;
            case 'b':
				/* bind */
				test_device_bind();
				break;
            case 'u':
				/* unbind */
				test_device_unbind();
				break;
			case 'h':
				/* heartbeat */
				test_device_fresh_heatbeat();
				break;
			case 'U':
				/* unactive */
				test_unactive_gw();
				break;
			case 'p':
				test_permit_join();
				break;
            case 'q':
				exit(0);
				break;
            default:
				print_usage();
				break;
		}
	}

    return 0;
}
