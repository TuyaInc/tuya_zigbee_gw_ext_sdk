#ifndef TUYA_IOT_TYPES_H
#define TUYA_IOT_TYPES_H

#define FW_URL_MAX          255
#define SW_VER_MAX          10
#define FW_HMAC_MAX         64

#define Z3_DEV_ID_LEN       32
#define Z3_MANU_NAME_LEN    32
#define Z3_MODEL_ID_LEN     32

typedef unsigned int   uint_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;
typedef unsigned char  byte_t;

typedef enum {
    TY_LOG_LEVEL_ERR     = 0,
    TY_LOG_LEVEL_WARN    = 1,
    TY_LOG_LEVEL_NOTICE  = 2,
    TY_LOG_LEVEL_INFO    = 3,
    TY_LOG_LEVEL_DEBUG   = 4,
    TY_LOG_LEVEL_TRACE   = 5
} ty_log_lovel_t;

typedef enum {
	TY_CONN_MODE_AP      = 0,
	TY_CONN_MODE_EZ      = 1,
} ty_conn_mode_t;

typedef enum {
	ZIGBEE_DEV   = 2,
	INFRARED_DEV = 3,
	OTHER_DEV    = 4,
	BLE_DEV      = 5,
} dev_type_t;

enum {
    DEV_RESTORE_FACTORY_DEFAULTS      = 0,
    DEV_RESTORE_FACTORY_DATA_DEFAULTS = 1,
};

enum {
	DP_TYPE_BOOL   = 0,
	DP_TYPE_VALUE  = 1,
	DP_TYPE_STR    = 2,
	DP_TYPE_ENUM   = 3,
	DP_TYPE_BITMAP = 4,
};

typedef struct {
	byte_t dpid;
	byte_t type;
	union {
		int     dp_value;
		uint_t  dp_enum;
		char   *dp_str;
		int     dp_bool;
		uint_t  dp_bitmap;
	} value;
	uint_t time_stamp;
} ty_obj_dp_s;

typedef struct {
    byte_t       cmd_tp; 
    byte_t       dtt_tp;
    char        *cid; 
    char        *mb_id;
    uint_t       dps_cnt;
    ty_obj_dp_s  dps[0];
} ty_recv_obj_dp_s;

typedef struct {
	byte_t  cmd_tp;
	byte_t  dtt_tp;
	char   *cid;
	byte_t  dpid;
	char   *mb_id;
	uint_t  len;
	byte_t  data[0];
} ty_recv_raw_dp_s;

typedef struct {
    byte_t tp; /* refer to dev_type_t */
    char fw_url[FW_URL_MAX+1];
    char sw_ver[SW_VER_MAX+1];
    uint_t file_size;
    char fw_hmac[FW_HMAC_MAX+1];
} ty_fw_info_s;

typedef struct {
	char *rule_id;
} ty_scene_attr_s;

typedef struct {
	char *storage_path;
	char *cache_path;
	char *tty_device;
	int tty_baudrate;
	char *eth_ifname;
	char *wifi_ifname;
	char *ssid;
	char *password;
	char *ver;
	int is_engr;
	ty_conn_mode_t wifi_mode;
	ty_log_lovel_t log_level;
} ty_gw_attr_s;

typedef struct {
	int  (*get_uuid_authkey_cb)(char *uuid, int uuid_size, char *authkey, int authkey_size);
	int  (*get_product_key_cb)(char *pk, int pk_size);
	int  (*get_ssid_psk_cb)(char *ssid, int ssid_size, char *psk, int psk_size);
	int  (*gw_upgrade_cb)(const char *img_file);
	void (*gw_reboot_cb)(void);
	void (*gw_reset_cb)(void);
	void (*gw_engineer_finished_cb)(void);
	int  (*gw_fetch_local_log_cb)(char *path, int path_len);
    int  (*gw_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int  (*gw_raw_dp_cb)(ty_recv_raw_dp_s *dp);
	int  (*gw_active_status_changed_cb)(const char *dev_id, int status);
	int  (*gw_online_status_changed_cb)(const char *dev_id, int status);	
} ty_gw_cbs;

typedef struct {
	int (*misc_dev_add_cb)(int permit, uint_t timeout);
	int (*misc_dev_del_cb)(const char *dev_id);
	int (*misc_dev_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int (*misc_dev_raw_dp_cb)(ty_recv_raw_dp_s *dp);
	int (*misc_dev_bind_ifm_cb)(const char *dev_id, int result);
	int (*misc_dev_upgrade_cb)(const char *dev_id, const ty_fw_info_s *fw);
	int (*misc_dev_reset_cb)(const char *dev_id);
} ty_misc_dev_cbs;

typedef struct {
	char     id[Z3_DEV_ID_LEN+1];
	uint16_t node_id;
	char     manu_name[Z3_MANU_NAME_LEN+1];
	char     model_id[Z3_MODEL_ID_LEN+1];
	char     rejoin_flag;
} ty_z3_desc_s;

typedef struct {
    char id[Z3_DEV_ID_LEN+1];
    uint16_t node_id;
    uint16_t profile_id;
    uint16_t cluster_id;
    uint8_t src_endpoint;
    uint8_t dst_endpoint;
    uint16_t group_id;
    uint8_t cmd_type;
    uint8_t cmd_id;
    uint8_t frame_type;
    char disable_ack;
    uint16_t msg_length;
    uint8_t *message;
} ty_z3_aps_frame_s;

typedef struct {
    int (*z3_active_status_changed_cb)(const char *id, int status);
    int (*z3_dev_obj_dp_cb)(ty_recv_obj_dp_s *dp);
	int (*z3_dev_raw_dp_cb)(ty_recv_raw_dp_s *dp);
    int (*z3_dev_read_attr_cb)(const char *id, uint_t uddd);
    int (*z3_dev_join_cb)(ty_z3_desc_s *dev);
    int (*z3_dev_leave_cb)(const char *id);
    int (*z3_zcl_report_cb)(ty_z3_aps_frame_s *frame);
    int (*z3_all_zcl_report_cb)(ty_z3_aps_frame_s *frame);
} ty_z3_dev_cbs;

#endif
