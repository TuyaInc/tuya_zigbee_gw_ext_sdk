#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "tuya_infra_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "003tuyatestf7f149185"
#define AUTHKEY      "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"
#define PRODUCT_KEY  "GXxoKf27eVjA7x1c"

int iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

int iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

int iot_fetch_local_log_cb(char *path, int path_len)
{
	char cmd[128] = {0};

	snprintf(path, path_len, "/tmp/log.tgz");

	snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", path);
	system(cmd);

	return 0;
}

int main(int argc, char **argv)
{
    int ret = 0;

    ty_gw_attr_s gw_attr = {
        .storage_path = "./",
        .cache_path = "/tmp/",
        .tty_device = "/dev/ttyS1",
        .tty_baudrate = 115200,
        .eth_ifname = "br0",
        .ver = "1.0.0",
        .log_level = TY_LOG_LEVEL_DEBUG
    };

    ty_gw_cbs gw_cbs = {
        .get_uuid_authkey_cb = iot_get_uuid_authkey_cb,
        .get_product_key_cb = iot_get_product_key_cb,
        .gw_fetch_local_log_cb = iot_fetch_local_log_cb,
    };

    ret = tuya_user_iot_init(&gw_attr, &gw_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_init failed\n");
        return ret;
    }

	while (1) {
		sleep(10);
	}

    return 0;
}
