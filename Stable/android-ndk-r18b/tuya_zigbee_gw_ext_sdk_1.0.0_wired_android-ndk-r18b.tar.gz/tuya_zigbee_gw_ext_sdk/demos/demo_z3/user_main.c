#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "command-id.h"
#include "cluster-id.h"
#include "tuya_infra_api.h"
#include "tuya_z3_device_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "003tuyatestf7f149185"
#define AUTHKEY      "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"
#define PRODUCT_KEY  "GXxoKf27eVjA7x1c"

#define Z3_PROFILE_ID_HA           0x0104

#define Z3_CMD_TYPE_GLOBAL         0x01
#define Z3_CMD_TYPE_PRIVATE        0x02
#define Z3_CMD_TYPE_ZDO            0x03

#define READ_ATTRIBUTES_RESPONSE_COMMAND_ID 0x01
#define REPORT_ATTRIBUTES_COMMAND_ID        0x0A
#define READ_ATTRIBUTER_RESPONSE_HEADER     3 /* Attributer ID: 2 Bytes, Status: 1 Btye */
#define REPORT_ATTRIBUTES_HEADER            2 /* Attributer ID: 2 Bytes */

static void print_usage(void)
{
    printf("usage:\r\n");
    printf("  s: send zcl cmd api unittest\r\n");
    printf("  d: leave ZigBee network api unittest\r\n");
    printf("  E: enable to add device api unittest\r\n");
    printf("  D: disable to add device api unittest\r\n");
    printf("  q: exit \r\n");
    printf("\r\n");
}

static int test_switch_onoff(const char *id, uint8_t dst_ep, int on)
{
    ty_z3_aps_frame_s data = {0};

    memset(&data, 0x00, sizeof(ty_z3_aps_frame_s));

    if (!id)
        return -1;

	printf("send cmd: %d\n", on);

    strncpy(data.id, id, sizeof(data.id));
    data.profile_id = Z3_PROFILE_ID_HA;
    data.cluster_id = ZCL_ON_OFF_CLUSTER_ID;
    data.cmd_type = Z3_CMD_TYPE_PRIVATE;
    data.src_endpoint = 0x01;
    data.dst_endpoint = dst_ep;

    data.msg_length = 0;

    if (on)
        data.cmd_id = ZCL_ON_COMMAND_ID;
    else 
        data.cmd_id = ZCL_OFF_COMMAND_ID;

    return tuya_user_iot_z3_send_zcl_cmd(&data);
}

static int iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

static int iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

static int iot_fetch_local_log_cb(char *path, int path_len)
{
	char cmd[128] = {0};

	snprintf(path, path_len, "/tmp/log.tgz");

	snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", path);
	system(cmd);

	return 0;
}

static int z3_active_status_changed_cb(const char *id, int state)
{
    if (state)
        printf("device: %s bind to tuya cloud\n", id);
    else
        printf("device: %s unbind from tuya cloud\n", id);

    return 0;
}

static int z3_dev_obj_dp_cb(ty_recv_obj_dp_s *dp)
{
	int i = 0;
	
    printf("cmd_tp: %d, dtt_tp: %d, dps_cnt: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dps_cnt);

    /* USER TODO */

	for (i = 0; i < dp->dps_cnt; i++) {
		printf("dpid: %d\n", dp->dps[i].dpid);
		switch (dp->dps[i].type) {
			case DP_TYPE_BOOL:
				printf("dp_bool value: %d\n", dp->dps[i].value.dp_bool);
                /* test switch */
                test_switch_onoff(dp->cid, dp->dps[i].dpid, dp->dps[i].value.dp_bool);
				break;
			case DP_TYPE_VALUE:
				printf("dp_value value: %d\n", dp->dps[i].value.dp_value);
				break;
			case DP_TYPE_ENUM:
				printf("dp_enum value: %d\n", dp->dps[i].value.dp_enum);
				break;
			case DP_TYPE_STR:
				printf("dp_str value: %s\n", dp->dps[i].value.dp_str);
				break;
		}
	}

    return 0;
}

static int z3_dev_read_attr_cb(const char *id, uint_t uddd)
{
    ty_z3_aps_frame_s data = {0};
	uint16_t atrr_buf[5] = {0x0000, 0x4001, 0x4002, 0x8001, 0x5000};

	if (!id)
		return -1;

    printf("read device: %s attribute, uddd: 0x%08x\n", id, uddd);

    /* USER TODO */
    
    memset(&data, 0x00, sizeof(ty_z3_aps_frame_s));

    strncpy(data.id, id, sizeof(data.id));
    data.profile_id = Z3_PROFILE_ID_HA;
    data.cluster_id = ZCL_ON_OFF_CLUSTER_ID;
    data.cmd_type = Z3_CMD_TYPE_GLOBAL;
    data.src_endpoint = 0x01;
    data.dst_endpoint = 0xff;
    data.cmd_id = ZCL_READ_ATTRIBUTES_COMMAND_ID;

    data.msg_length = sizeof(atrr_buf);
	data.message = (uint8_t *)atrr_buf;

    return tuya_user_iot_z3_send_zcl_cmd(&data);
}

static int z3_dev_join_cb(ty_z3_desc_s *dev)
{
    char pk[] = "nPGIPl5D";
    char ver[] = "1.0.7";
    uint_t uddd = 0x2000200;

    if (!dev) {
        printf("invalid param\n");
        return -1;
    }

    printf("device: %s joined ZigBee network\n", dev->id);
    printf("     node_id: 0x%04x\n", dev->node_id);
    printf("   manu_name: %s\n", dev->manu_name);
    printf("    model_id: %s\n", dev->model_id);
    printf(" rejoin_flag: %d\n", dev->rejoin_flag);

    /* USER TODO */

    int ret = tuya_user_iot_z3_dev_bind(uddd, dev->id, pk, ver);
    if (ret != 0) {
        printf("tuya_user_iot_bind_dev failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

static int z3_dev_leave_cb(const char *id)
{
    printf("device: %s left ZigBee network\n", id);

    /* USER TODO */

    return 0;
}

static int z3_zcl_report_cb(ty_z3_aps_frame_s *frame)
{
    int i = 0, ret = 0;
    int dps_cnt = 1;
	ty_obj_dp_s *dps = NULL;
    
    printf("        id: %s\n", frame->id);
    printf("profile_id: 0x%04x\n", frame->profile_id);
    printf("cluster_id: 0x%04x\n", frame->cluster_id);
    printf("   node_id: 0x%04x\n", frame->node_id);
    printf("    src_ep: %d\n", frame->src_endpoint);
    printf("    dst_ep: %d\n", frame->dst_endpoint);
    printf("  group_id: %d\n", frame->group_id);
    printf("  cmd_type: %d\n", frame->cmd_type);
    printf("   command: 0x%x\n", frame->cmd_id);
    printf("frame_type: %d\n", frame->frame_type);
    printf("   msg_len: %d\n", frame->msg_length);
    printf("       msg: ");
    for(i = 0; i < frame->msg_length; i++)
        printf("%02x ", frame->message[i]);
    
    printf("\n");

    /* USER TODO */

    /* test one switch */
    dps = (ty_obj_dp_s *)malloc(dps_cnt * sizeof(ty_obj_dp_s));
	if (dps == NULL) {
		printf("malloc failed\n");
		return -1;
	}

    dps[0].dpid = frame->src_endpoint;
	dps[0].type = DP_TYPE_BOOL;

    if ((frame->profile_id == Z3_PROFILE_ID_HA) && \
        (frame->cluster_id == ZCL_ON_OFF_CLUSTER_ID)) {
        if (frame->cmd_id == REPORT_ATTRIBUTES_COMMAND_ID) {
            dps[0].value.dp_bool = frame->message[REPORT_ATTRIBUTES_HEADER+1];
        } else if (frame->cmd_id == READ_ATTRIBUTES_RESPONSE_COMMAND_ID) {
            dps[0].value.dp_bool = frame->message[READ_ATTRIBUTER_RESPONSE_HEADER+1];
        } else {
            free(dps);
            return -1;
        }
    }
    
	ret = tuya_user_iot_report_dp_json_async(frame->id, dps, dps_cnt);
	if (ret != 0) {
		printf("tuya_user_iot_report_dp_json_async failed, ret: %d\n", ret);
        return ret;
	}

	if (dps != NULL)
		free(dps);

    return 0;
}

static int z3_all_zcl_report_cb(ty_z3_aps_frame_s *frame)
{
    int i = 0;
    
    printf("        id: %s\n", frame->id);
    printf("profile_id: 0x%04x\n", frame->profile_id);
    printf("cluster_id: 0x%04x\n", frame->cluster_id);
    printf("   node_id: 0x%04x\n", frame->node_id);
    printf("    src_ep: %d\n", frame->src_endpoint);
    printf("    dst_ep: %d\n", frame->dst_endpoint);
    printf("  group_id: %d\n", frame->group_id);
    printf("  cmd_type: %d\n", frame->cmd_type);
    printf("   command: 0x%x\n", frame->cmd_id);
    printf("frame_type: %d\n", frame->frame_type);
    printf("   msg_len: %d\n", frame->msg_length);
    printf("       msg: ");
    for(i = 0; i < frame->msg_length; i++)
        printf("%02x ", frame->message[i]);
    
    printf("\n");

    /* USER TODO */

    return 0;
}

static void test_send_cmd(void)
{
    int i = 0, val = 0;
	uint8_t ep = 0x01;
    char id[] = "000d6ffffe6d81ec";

    val ^= 1;
    test_switch_onoff(id, ep, val);

    val ^= 1;
    test_switch_onoff(id, ep, val);

    for (i = 0; i < 10; i++) { 
        val ^= 1;     
        test_switch_onoff(id, ep, val);
        usleep(100);

        val ^= 1; 
        test_switch_onoff(id, ep, val);
        usleep(100);
    }
}

static void test_del_dev(void)
{
    char id[] = "000d6ffffe6d81ec";

    tuya_user_iot_z3_del_dev(id);
}

static void test_permit_join(int en)
{
	int ret = 0;

	ret = tuya_user_iot_permit_join(en);
	if (ret != 0) {
		printf("tuya_user_iot_permit_join failed\n");
		return;
	}
}

int main(int argc, char **argv)
{
    int ret = 0;
    char line[256] = {0};

    ty_gw_attr_s gw_attr = {
        .storage_path = "./",
        .cache_path = "/tmp/",
        .tty_device = "/dev/ttyS1",
        .tty_baudrate = 115200,
        .eth_ifname = "br0",
        .ver = "1.0.0",
        .log_level = TY_LOG_LEVEL_DEBUG
    };
    
    ty_gw_cbs gw_cbs = {
        .get_uuid_authkey_cb = iot_get_uuid_authkey_cb,
        .get_product_key_cb = iot_get_product_key_cb,
        .gw_fetch_local_log_cb = iot_fetch_local_log_cb,
    };

    ty_z3_dev_cbs z3_dev_cbs = {
        .z3_active_status_changed_cb = z3_active_status_changed_cb,
        .z3_dev_obj_dp_cb = z3_dev_obj_dp_cb, 
        .z3_dev_read_attr_cb = z3_dev_read_attr_cb,
        .z3_dev_join_cb = z3_dev_join_cb,
        .z3_dev_leave_cb = z3_dev_leave_cb,
        .z3_zcl_report_cb = z3_zcl_report_cb,
        .z3_all_zcl_report_cb = z3_all_zcl_report_cb,
	};

    ret = tuya_user_iot_reg_z3_dev_cb(&z3_dev_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_reg_z3_dev_cb failed\n");
        return ret;
    }

    ret = tuya_user_iot_init(&gw_attr, &gw_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_init failed\n");
        return ret;
    }

    ret = tuya_user_iot_z3_set_custom_device("/tmp/test.json");
    if (ret != 0) {
        printf("tuya_user_iot_z3_set_custom_device failed, ret: %d\n", ret);
        return ret;
    }

    print_usage();
	while (1) {
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
            case 's':
	    		test_send_cmd();
                break;
            case 'd':
                test_del_dev();
                break;
			case 'E':
				test_permit_join(1);
				break;
			case 'D':
				test_permit_join(0);
				break;
            case 'q':
	    		exit(0);
	    		break;
            default:
	    		print_usage();
	    		break;
	    }
	}

    return 0;
}
