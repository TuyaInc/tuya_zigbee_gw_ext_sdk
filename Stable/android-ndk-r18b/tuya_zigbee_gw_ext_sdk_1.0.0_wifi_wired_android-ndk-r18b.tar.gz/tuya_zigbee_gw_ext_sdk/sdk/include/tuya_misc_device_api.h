#ifndef TUYA_MISC_DEVICE_API_H
#define TUYA_MISC_DEVICE_API_H

#include "tuya_iot_types.h"

/**
 * @brief    register misc device management callbacks.
 *
 * @param cbs.  a set of callbacks.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_reg_misc_dev_cb(ty_misc_dev_cbs *cbs);

/**
 * @brief    bind misc device to tuya cloud.
 *
 * @param uddd.   custom filed, the highest bit must be 1.
 * @param dev_id. device unique ID.
 * @param pid.    product ID.
 * @param ver.    device software version.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_dev_bind(uint_t uddd, const char *dev_id, const char *pk, const char *ver);

/**
 * @brief    unbind misc device from tuya cloud.
 *
 * @param dev_id. device unique ID.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_unbind_dev(const char *dev_id);

/**
 * @brief    fresh misc device online status.
 *
 * @param dev_id.  device unique ID.
 * @param timeout. offline timeout, uint: seconds.
 * 
 * @retval   0: sucess
 * @retval  !0: failure
 */
int tuya_user_iot_misc_fresh_dev_hb(const char *dev_id, uint_t timeout);

#endif