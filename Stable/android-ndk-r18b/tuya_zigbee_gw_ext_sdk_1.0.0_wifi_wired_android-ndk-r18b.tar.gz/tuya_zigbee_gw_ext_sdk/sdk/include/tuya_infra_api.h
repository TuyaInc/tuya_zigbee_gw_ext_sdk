#ifndef TUYA_INFRA_API_H
#define TUYA_INFRA_API_H

#include "tuya_iot_types.h"

/**
 * @brief    initiate sdk.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_init(ty_gw_attr_s *attr, ty_gw_cbs *cbs);

/**
 * @brief    report obj dp to tuay cloud.
 *
 * @param dev_id.  device unique ID.
 * @param dps.     dp array.
 * @param dps_cnt. dp array length.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_report_dp_json_async(const char *dev_id, ty_obj_dp_s *dps, uint_t dps_cnt);

/**
 * @brief    report raw dp to tuya cloud.
 *
 * @param dev_id. device unique ID.
 * @param dpid.   dp ID.
 * @param dps.    raw data.
 * @param len.    raw data length.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_report_dp_raw_sync(const char *dev_id, uint_t dpid, byte_t *data, uint_t len);

/**
 * @brief    execute scene linkage.
 *
 * @param attr. attributes of scene linkage.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_exec_scene(ty_scene_attr_s *attr);

/**
 * @brief    unactive gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_unactive_gw(void);

/**
 * @brief    active gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_active_gw(const char *token);

/**
 * @brief    allow or disallow subdevice to join network.
 *
 * @param permit. 0: disallow, 1: allow.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_permit_join(int permit);

#endif
