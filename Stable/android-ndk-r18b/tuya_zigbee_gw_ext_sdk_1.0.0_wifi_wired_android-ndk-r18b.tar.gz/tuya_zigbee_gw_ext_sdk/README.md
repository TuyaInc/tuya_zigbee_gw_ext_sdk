SDK产物介绍
-----------  

```  
.
├── build_app.sh   # 编译脚本
├── CHANGE_LOG.md  # 版本信息
├── demos
│   ├── demo_engr  # ZigBee网关支持工程部署的示例程序
│   ├── demo_gw    # ZigBee网关的示例程序
│   ├── demo_misc  # ZigBee网关接入非ZigBee子设备的示例程序
│   └── demo_z3    # ZigBee网关接入ZigBee子设备的示例程序
├── Makefile
└── sdk
    ├── include    # SDK头文件
    └── lib        # SDK库文件
```  

快速编译  
--------  

1. 修改 `Makefile` 文件，将交叉编译工具链的路径配置到 `COMPILE_PREX` 变量。  
2. 运行 `sh build_app.sh demo_gw`，将编译出来的应用以及SDK库文件拷贝到目标系统，编译产生的应用位于 `output/demo_gw` 目录下。  
