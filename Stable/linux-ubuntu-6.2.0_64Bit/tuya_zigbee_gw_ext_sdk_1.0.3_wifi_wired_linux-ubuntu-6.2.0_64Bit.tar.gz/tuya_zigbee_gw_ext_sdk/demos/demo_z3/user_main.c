#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#include "tuya_gw_infra_api.h"
#include "tuya_gw_z3_api.h"
#include "tuya_gw_dp_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "003tuyatestf7f149185"
#define AUTHKEY      "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"
#define PRODUCT_KEY  "GXxoKf27eVjA7x1c"

#define Z3_PROFILE_ID_HA           0x0104

#define ZCL_ON_OFF_CLUSTER_ID      0x0006

#define Z3_CMD_TYPE_GLOBAL         0x01
#define Z3_CMD_TYPE_PRIVATE        0x02
#define Z3_CMD_TYPE_ZDO            0x03

#define ZCL_OFF_COMMAND_ID         0x00
#define ZCL_ON_COMMAND_ID          0x01

#define ZCL_READ_ATTRIBUTES_COMMAND_ID      0x00
#define READ_ATTRIBUTES_RESPONSE_COMMAND_ID 0x01
#define REPORT_ATTRIBUTES_COMMAND_ID        0x0A
#define READ_ATTRIBUTER_RESPONSE_HEADER     3 /* Attributer ID: 2 Bytes, Status: 1 Btye */
#define REPORT_ATTRIBUTES_HEADER            2 /* Attributer ID: 2 Bytes */

static void usage(void)
{
    printf("usage:\r\n");
    printf("  u: unactive gw unittest\r\n");
    printf("  p: permit device join unittest\r\n");
    printf("  s: send zcl commnad unittest\r\n");
    printf("  d: delete device unittest\r\n");
    printf("  q: exit \r\n");
    printf("\r\n"); 
}

static void test_switch_onoff(const char *id, uint8_t dst_ep, int on)
{
    int ret = 0;
    ty_z3_aps_frame_s data = {0};

    memset(&data, 0x00, sizeof(ty_z3_aps_frame_s));

    strncpy(data.id, id, sizeof(data.id));
    data.profile_id = Z3_PROFILE_ID_HA;
    data.cluster_id = ZCL_ON_OFF_CLUSTER_ID;
    data.cmd_type = Z3_CMD_TYPE_PRIVATE;
    data.src_endpoint = 0x01;
    data.dst_endpoint = dst_ep;

    data.msg_length = 0;

    if (on)
        data.cmd_id = ZCL_ON_COMMAND_ID;
    else 
        data.cmd_id = ZCL_OFF_COMMAND_ID;

    ret = tuya_user_iot_z3_dev_send_zcl_cmd(&data);
    if (ret != 0) {
        printf("tuya_user_iot_z3_dev_send_zcl_cmd error, ret: %d\n", ret);
        return;
    }

    return ;
}

static int _iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

static int _iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

static int _gw_fetch_local_log_cb(char *path, int path_len)
{
    char cmd[256] = {0};

    printf("gw fetch local log callback\n");
    /* USER TODO */

    /*
    snprintf(file, len, "/tmp/log.tgz");

    snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", file);
    system(cmd);
    */

    return 0;
}

static void _gw_reboot_cb(void)
{
    printf("gw reboot callback\n");
    /* USER TODO */

    return;
}

static void _gw_reset_cb(void)
{
    printf("gw reset callback\n");
    /* USER TODO */

    return;
}

static int _gw_upgrade_cb(const char *img)
{
    printf("gw upgrade callback\n");
    /* USER TODO */

    return 0;
}

static int _dev_obj_cmd_cb(ty_obj_cmd_s *dp)
{
    int i = 0;
	
    printf("device obj cmd callback\n");
    printf("cmd_tp: %d, dtt_tp: %d, dps_cnt: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dps_cnt);

    for (i = 0; i < dp->dps_cnt; i++) {
        printf("dpid: %d\n", dp->dps[i].dpid);
        switch (dp->dps[i].type) {
        case DP_TYPE_BOOL:
            printf("dp_bool value: %d\n", dp->dps[i].value.dp_bool);
            break;
        case DP_TYPE_VALUE:
            printf("dp_value value: %d\n", dp->dps[i].value.dp_value);
            break;
        case DP_TYPE_ENUM:
            printf("dp_enum value: %d\n", dp->dps[i].value.dp_enum);
            break;
        case DP_TYPE_STR:
            printf("dp_str value: %s\n", dp->dps[i].value.dp_str);
            break;
        }
    }
    /* USER TODO */

    if (dp->cid != NULL) {
        tuya_user_iot_report_obj_dp(dp->cid, dp->dps, dp->dps_cnt);
        /* test on smart switch */
        test_switch_onoff(dp->cid, 0x01, dp->dps[0].value.dp_bool);
	}

    return 0; 
}

static int _dev_raw_cmd_cb(ty_raw_cmd_s *dp)
{
    int i = 0;

    printf("device raw cmd callback\n");
    printf("cmd_tp: %d, dtt_tp: %d, dpid: %d, len: %u\n", dp->cmd_tp, dp->dtt_tp, dp->dpid, dp->len);

    printf("data: ");
    for (i = 0; i < dp->len; i++)
        printf("%02x ", dp->data[i]);

    printf("\n");
    /* USER TODO */

    return 0;
}

static int _z3_dev_active_state_changed_cb(const char *id, int state)
{
    printf("device active state changed callback\n");
    printf("id: %s, state: %d\n", id, state);
    /* USER TODO */

    return 0;
}

static int _z3_dev_init_data_cb(void)
{
    int ret = 0;
    const char *id = "000d6ffffe6d81ec";
    ty_z3_aps_frame_s data = {0};
    uint16_t atrr_buf[5] = {0x0000, 0x4001, 0x4002, 0x8001, 0x5000};

    printf("device read attribute callback\n");
    /* USER TODO */

    memset(&data, 0x00, sizeof(ty_z3_aps_frame_s));

    strncpy(data.id, id, sizeof(data.id));
    data.profile_id = Z3_PROFILE_ID_HA;
    data.cluster_id = ZCL_ON_OFF_CLUSTER_ID;
    data.cmd_type = Z3_CMD_TYPE_GLOBAL;
    data.src_endpoint = 0x01;
    data.dst_endpoint = 0xff;
    data.cmd_id = ZCL_READ_ATTRIBUTES_COMMAND_ID;

    data.msg_length = sizeof(atrr_buf);
    data.message = (uint8_t *)atrr_buf;

    ret = tuya_user_iot_z3_dev_send_zcl_cmd(&data);
    if (ret != 0) {
        printf("tuya_user_iot_z3_dev_send_zcl_cmd error, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

static int _z3_dev_join_cb(ty_z3_desc_s *desc)
{
    int ret = 0;
    char *pid = "nPGIPl5D";
    char *ver = "1.0.7";
    uint32_t uddd = 0x8000200;

    printf("device join callback\n");
    printf("          id: %s\n", desc->id);
    printf("     node_id: 0x%04x\n", desc->node_id);
    printf("   manu_name: %s\n", desc->manu_name);
    printf("    model_id: %s\n", desc->model_id);
    printf(" rejoin_flag: %d\n", desc->rejoin_flag);
    /* USER TODO */

    ret = tuya_user_iot_z3_dev_bind(uddd, desc->id, pid, ver);
    if (ret != 0) {
        printf("tuya_user_iot_z3_dev_bind failed, ret: %d\n", ret);
        return ret;
    }

    return 0;
}

static int _z3_dev_leave_cb(const char *id)
{
    printf("device leave callback\n");
    /* USER TODO */

    return 0;
}

static int _z3_dev_zcl_report_cb(ty_z3_aps_frame_s *frame)
{
    int i = 0, ret = 0;
    int dps_cnt = 1;
	ty_dp_s *dps = NULL;
    
    printf("device zcl report callback\n");
    printf("        id: %s\n", frame->id);
    printf("profile_id: 0x%04x\n", frame->profile_id);
    printf("cluster_id: 0x%04x\n", frame->cluster_id);
    printf("   node_id: 0x%04x\n", frame->node_id);
    printf("    src_ep: %d\n", frame->src_endpoint);
    printf("    dst_ep: %d\n", frame->dst_endpoint);
    printf("  group_id: %d\n", frame->group_id);
    printf("  cmd_type: %d\n", frame->cmd_type);
    printf("   command: 0x%02x\n", frame->cmd_id);
    printf("frame_type: %d\n", frame->frame_type);
    printf("   msg_len: %d\n", frame->msg_length);
    printf("       msg: ");
    for (i = 0; i < frame->msg_length; i++)
        printf("%02x ", frame->message[i]);
    
    printf("\n");
    /* USER TODO */

    /* test one switch */
    dps = (ty_dp_s *)malloc(dps_cnt * sizeof(ty_dp_s));
    if (dps == NULL) {
        printf("malloc failed\n");
        return -1;
    }

    dps[0].dpid = 0x01;
    dps[0].type = DP_TYPE_BOOL;

    if ((frame->profile_id == Z3_PROFILE_ID_HA) && \
        (frame->cluster_id == ZCL_ON_OFF_CLUSTER_ID)) {
        if (frame->cmd_id == REPORT_ATTRIBUTES_COMMAND_ID) {
            dps[0].value.dp_bool = frame->message[REPORT_ATTRIBUTES_HEADER+1];
        } else if (frame->cmd_id == READ_ATTRIBUTES_RESPONSE_COMMAND_ID) {
            dps[0].value.dp_bool = frame->message[READ_ATTRIBUTER_RESPONSE_HEADER+1];
        } else {
            free(dps);
            return -1;
        }
    }
    
    ret = tuya_user_iot_report_obj_dp(frame->id, dps, dps_cnt);
    if (ret != 0) {
        printf("tuya_user_iot_report_obj_dp error, ret: %d\n", ret);
        free(dps);
        return ret;
    }

    if (dps != NULL)
        free(dps);

    return 0;
}

static void test_tuya_user_iot_unactive_gw(void)
{
    tuya_user_iot_unactive_gw();

    return;
}

static void test_tuya_user_iot_permit_join(void)
{
    static bool permit = false;
    int ret = 0;

    permit ^= 1;

    ret = tuya_user_iot_permit_join(permit);
    if (ret != 0) {
        printf("tuya_user_iot_permit_join error, ret: %d\n", ret);
        return;
    }

    return;
}

static void test_tuya_user_iot_z3_dev_send_zcl_cmd(void)
{
    int i = 0, val = 0;
	uint8_t ep = 0x01;
    char *id = "000d6ffffe6d81ec";

    val ^= 1;
    test_switch_onoff(id, ep, val);

    val ^= 1;
    test_switch_onoff(id, ep, val);

    for (i = 0; i < 10; i++) { 
        val ^= 1;     
        test_switch_onoff(id, ep, val);
        sleep(1);

        val ^= 1; 
        test_switch_onoff(id, ep, val);
        sleep(1);
    }

    return;
}

static void test_tuya_user_iot_z3_dev_del(void)
{
    int ret = 0;
    char *id = "000d6ffffe6d81ec";

    ret = tuya_user_iot_z3_dev_del(id);
    if (ret != 0) {
        printf("tuya_user_iot_z3_dev_del error, ret: %d\n", ret);
        return;
    }

    return;
}

int main(int argc, char **argv)
{
    int ret = 0;
    bool debug = true;
    char line[256] = {0};

    ty_gw_attr_s gw_attr = {
        .storage_path = "./",
        .cache_path = "/tmp/",
        .tty_device = "/dev/ttyS1",
        .tty_baudrate = 115200,
        .eth_ifname = "br0",
        .ver = "1.0.0",
        .uz_cfg = "./devices.json",
        .log_level = TY_LOG_LEVEL_DEBUG
    };

    ty_gw_infra_cbs_s gw_infra_cbs = {
        .get_uuid_authkey_cb = _iot_get_uuid_authkey_cb,
        .get_product_key_cb = _iot_get_product_key_cb,
        .gw_fetch_local_log_cb = _gw_fetch_local_log_cb,
        .gw_reboot_cb = _gw_reboot_cb,
        .gw_reset_cb = _gw_reset_cb,
        .gw_upgrade_cb = _gw_upgrade_cb,
    };

    ty_dev_cmd_cbs_s dev_cmd_cbs = {
        .dev_obj_cmd_cb = _dev_obj_cmd_cb,
        .dev_raw_cmd_cb = _dev_raw_cmd_cb,
    };

    ty_z3_dev_cbs_s z3_dev_cbs = {
        .z3_dev_active_state_changed_cb = _z3_dev_active_state_changed_cb,
        .z3_dev_init_data_cb = _z3_dev_init_data_cb,
        .z3_dev_join_cb = _z3_dev_join_cb,
        .z3_dev_leave_cb = _z3_dev_leave_cb,
        .z3_dev_zcl_report_cb = _z3_dev_zcl_report_cb,
    };

    ret = tuya_user_iot_reg_dev_cmd_cb(&dev_cmd_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_reg_dev_cmd_cb failed, ret: %d\n", ret);
        return ret;
    }

    ret = tuya_user_iot_reg_z3_dev_cb(&z3_dev_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_reg_z3_dev_cb failed, ret: %d\n", ret);
        return ret;
    }

    ret = tuya_user_iot_init(&gw_attr, &gw_infra_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_init failed\n");
        return ret;
    }

    while (1) {
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
        case 'u':
            test_tuya_user_iot_unactive_gw();
            break;
        case 'p':
            test_tuya_user_iot_permit_join();
            break;
        case 's':
            test_tuya_user_iot_z3_dev_send_zcl_cmd();
            break;
        case 'd':
            test_tuya_user_iot_z3_dev_del();
            break;
        case 'q':
            exit(EXIT_SUCCESS);
            break;
        default:
            usage();
            break;
        }
    }

    return 0;
}
