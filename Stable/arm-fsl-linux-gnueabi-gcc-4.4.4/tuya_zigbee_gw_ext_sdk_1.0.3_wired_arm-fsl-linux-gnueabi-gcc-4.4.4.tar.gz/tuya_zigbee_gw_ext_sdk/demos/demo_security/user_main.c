#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "tuya_gw_infra_api.h"
#include "tuya_gw_security_api.h"

/* must apply for uuid, authkey and product key from tuya iot develop platform */
#define UUID         "tuya6d7902ffa78e2ff3"
#define AUTHKEY      "u4iG6O6vfGY0FL0Jf5uZShLKF2bSLxNc"
#define PRODUCT_KEY  "keyk9nqrjnhrt9mj"

static void usage(void)
{
    printf("usage:\r\n");
    printf("  u: unactive gw unittest\r\n");
    printf("  p: permit device join unittest\r\n");
    printf("  q: exit \r\n");
    printf("\r\n"); 
}

static int _iot_get_uuid_authkey_cb(char *uuid, int uuid_size, char *authkey, int authkey_size)
{
	strncpy(uuid, UUID, uuid_size);
	strncpy(authkey, AUTHKEY, authkey_size);

	return 0;
}

static int _iot_get_product_key_cb(char *pk, int pk_size)
{
	strncpy(pk, PRODUCT_KEY, pk_size);

	return 0;
}

static int _gw_led_state_changed_cb(int state)
{
    printf("gw led state changed callback\n");
    printf("led state: %d\n", state);
    /* USER TODO */
    
    return 0;
}

static void _gw_reboot_cb(void)
{
    printf("gw reboot callback\n");
    /* USER TODO */

    return;
}

static void _gw_reset_cb(void)
{
    printf("gw reset callback\n");
    /* USER TODO */

    return;
}

static int _gw_upgrade_cb(const char *img)
{
    printf("gw upgrade callback\n");
    /* USER TODO */

    return 0;
}

static int _gw_fetch_local_log_cb(char *path, int path_len)
{
    char cmd[256] = {0};

    printf("gw fetch local log callback\n");
    /* USER TODO */

    snprintf(path, path_len, "/tmp/log.tgz");

    snprintf(cmd, sizeof(cmd), "tar -zvcf %s --absolute-names /tmp/tuya.log", path);
    system(cmd);

    return 0;
}

static void test_tuya_user_iot_unactive_gw(void)
{
    tuya_user_iot_unactive_gw();

    return;
}

static void test_tuya_user_iot_permit_join(void)
{
    static bool permit = false;
    int ret = 0;

    permit ^= 1;

    ret = tuya_user_iot_permit_join(permit);
    if (ret != 0) {
        printf("tuya_user_iot_permit_join error, ret: %d\n", ret);
        return;
    }

    return;
}

void _home_security_alarm_cb(void)
{
    printf("home security alarm callback\n");

    return;
}

void _home_security_alarm_cancel_cb(void)
{
    printf("home security alarm cancel callback\n");

    return;
}

void _home_security_disarmed_cb(void)
{
    printf("home security disarmed callback\n");

    return;
}

void _home_security_away_armed_cb(void)
{
    printf("home security away armed callback\n");

    return;
}

void _home_security_stay_armed_cb(void)
{
    printf("home security stay armed callback\n");

    return;
}

void _home_security_arm_ignore_cb(void)
{
    printf("home security arm ignore callback\n");

    return;
}

void _home_security_arm_countdown_cb(uint32_t time)
{
    printf("home security arm countdown callback\n");
    printf("countdown time: %d\n", time);

    return;
}

void _home_security_alarm_countdown_cb(uint32_t time)
{
    printf("home security alarm countdown callback\n");
    printf("countdown time: %d\n", time);

    return;
}

void _home_security_door_opened_cb(void)
{
    printf("home security door opened callback\n");

    return;
}

void _home_security_alarm_dev_cb(char *dev)
{
    printf("home security alarm dev callback\n");

    return;
}

int main(int argc, char **argv)
{
    int ret = 0;
    char line[256] = {0};

    ty_gw_attr_s gw_attr = {
        .storage_path = "./",
        .cache_path = "/tmp/",
        .tty_device = "/dev/ttyS1",
        .tty_baudrate = 115200,
        .eth_ifname = "eth1",
        .ver = "1.2.7",
        .log_level = TY_LOG_LEVEL_DEBUG
    };

    ty_gw_infra_cbs_s gw_infra_cbs = {
        .get_uuid_authkey_cb = _iot_get_uuid_authkey_cb,
        .get_product_key_cb = _iot_get_product_key_cb,
        .gw_fetch_local_log_cb = _gw_fetch_local_log_cb,
        .gw_led_state_changed_cb = _gw_led_state_changed_cb,
        .gw_reboot_cb = _gw_reboot_cb,
        .gw_reset_cb = _gw_reset_cb,
        .gw_upgrade_cb = _gw_upgrade_cb,
    };

    ty_home_security_cbs_s security_cbs = {
    	.home_security_alarm_cb = _home_security_alarm_cb,
    	.home_security_alarm_cancel_cb = _home_security_alarm_cancel_cb,
    	.home_security_disarmed_cb = _home_security_disarmed_cb,
    	.home_security_away_armed_cb = _home_security_away_armed_cb,
    	.home_security_stay_armed_cb = _home_security_stay_armed_cb,
    	.home_security_arm_ignore_cb = _home_security_arm_ignore_cb,
    	.home_security_arm_countdown_cb = _home_security_arm_countdown_cb,
    	.home_security_alarm_countdown_cb = _home_security_alarm_countdown_cb,
    	.home_security_door_opened_cb = _home_security_door_opened_cb,
    	.home_security_alarm_dev_cb = _home_security_alarm_dev_cb,
    };

    ret = tuya_user_iot_reg_home_security_cb(&security_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_reg_home_security_cb failed, ret: %d\n", ret);
        return ret;
    }

    ret = tuya_user_iot_init(&gw_attr, &gw_infra_cbs);
    if (ret != 0) {
        printf("tuya_user_iot_init failed\n");
        return ret;
    }

    while (1) {
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
        case 'u':
            test_tuya_user_iot_unactive_gw();
            break;
        case 'p':
            test_tuya_user_iot_permit_join();
            break;
        case 'q':
            exit(EXIT_SUCCESS);
            break;
        default:
            usage();
            break;
        }
    }

    return 0;
}
