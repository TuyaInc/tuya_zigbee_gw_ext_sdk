#ifndef TUYA_IOT_TYPES_H
#define TUYA_IOT_TYPES_H

#define FW_URL_MAX      255
#define SW_VER_MAX      10
#define FW_HMAC_MAX     64

typedef enum {
    TY_LOG_LEVEL_ERR     = 0,
    TY_LOG_LEVEL_WARN    = 1,
    TY_LOG_LEVEL_NOTICE  = 2,
    TY_LOG_LEVEL_INFO    = 3,
    TY_LOG_LEVEL_DEBUG   = 4,
    TY_LOG_LEVEL_TRACE   = 5
} ty_log_lovel_t;

typedef enum {
	TY_CONN_MODE_AP      = 0,
	TY_CONN_MODE_EZ      = 1,
} ty_conn_mode_t;

typedef unsigned int   uint_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned char  byte_t;

typedef enum {
	ZIGBEE_DEV   = 2,
	INFRARED_DEV = 3,
	OTHER_DEV    = 4,
	BLE_DEV      = 5,
} dev_type_t;

typedef enum {
    GW_STAT_ONLINE    = 0,
    GW_STAT_OFFLINE   = 1,
    GW_STAT_BIND      = 2,
    GW_STAT_UNBIND    = 3,
} ty_gw_stat_t;

typedef enum {
    DEV_STAT_ONLINE   = 0,
    DEV_STAT_OFFLINE  = 1,
    DEV_STAT_BIND     = 2,
    DEV_STAT_UNBIND   = 3,
} ty_dev_stat_t;

enum {
    DEV_RESTORE_FACTORY_DEFAULTS      = 0,
    DEV_RESTORE_FACTORY_DATA_DEFAULTS = 1,
};

enum {
	DP_TYPE_BOOL   = 0,
	DP_TYPE_VALUE  = 1,
	DP_TYPE_STR    = 2,
	DP_TYPE_ENUM   = 3,
	DP_TYPE_BITMAP = 4,
};

typedef struct {
	byte_t dpid;
	byte_t type;
	union {
		int     dp_value;
		uint_t  dp_enum;
		char   *dp_str;
		int     dp_bool;
		uint_t  dp_bitmap;
	} value;
	uint_t time_stamp;
} ty_obj_dp_s;

typedef struct {
    byte_t       cmd_tp; 
    byte_t       dtt_tp;
    char        *cid; 
    char        *mb_id;
    uint_t       dps_cnt;
    ty_obj_dp_s  dps[0];
} ty_recv_obj_dp_s;

typedef struct {
	byte_t  cmd_tp;
	byte_t  dtt_tp;
	char   *cid;
	byte_t  dpid;
	char   *mb_id;
	uint_t  len;
	byte_t  data[0];
} ty_recv_raw_dp_s;

typedef struct {
    byte_t tp; /* refer to dev_type_t */
    char fw_url[FW_URL_MAX+1];
    char sw_ver[SW_VER_MAX+1];
    uint_t file_size;
    char fw_hmac[FW_HMAC_MAX+1];
} ty_fw_info_s;

typedef struct {
	char *rule_id;
} ty_scene_attr_s;

#endif
