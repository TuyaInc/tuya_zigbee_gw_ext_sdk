Release notes:

1.0.2  
    - Fix third-party Zigbee device will be removed
    - Fix segmentfault raised by door lock device

1.0.1  
    - Add home security feature
    - Add engineering mode
    - Fix cannot switch between EZ and AP mode

1.0.0  
    - Initial version
