/**
 * @file tuya_gw_infra_api.h
 * @author lwl@tuya.com
 * @brief 
 * @version 0.1
 * @date 2020-03-20
 * 
 * @copyright Copyright (c) tuya.inc 2020
 * 
 */
#ifndef TUYA_GW_INFRA_API_H
#define TUYA_GW_INFRA_API_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    TY_LOG_LEVEL_ERR     = 0,
    TY_LOG_LEVEL_WARN    = 1,
    TY_LOG_LEVEL_NOTICE  = 2,
    TY_LOG_LEVEL_INFO    = 3,
    TY_LOG_LEVEL_DEBUG   = 4,
    TY_LOG_LEVEL_TRACE   = 5
} ty_log_lovel_t;

typedef enum {
	TY_CONN_MODE_AP_ONLY      = 0,
	TY_CONN_MODE_EZ_ONLY      = 1,
    TY_CONN_MODE_AP_FIRST     = 2,
    TY_CONN_MODE_EZ_FIRST     = 3,
} ty_conn_mode_t;

typedef struct {
    char *storage_path;
    char *cache_path;
    char *tty_device;
    int tty_baudrate;
    char *eth_ifname;
    char *wifi_ifname;
    char *ssid;
    char *password;
    char *ver;
    int is_engr;
    char *zfile;
    char *zall;
    ty_conn_mode_t wifi_mode;
    ty_log_lovel_t log_level;
} ty_gw_attr_s;

typedef struct {
    int  (*get_uuid_authkey_cb)(char *uuid, int uuid_size, char *authkey, int authkey_size);
    int  (*get_product_key_cb)(char *pk, int pk_size);
    int  (*get_ssid_key_cb)(char *ssid, int ssid_size, char *key, int key_size);
    int  (*gw_upgrade_cb)(const char *img_file);
    void (*gw_reboot_cb)(void);
    void (*gw_reset_cb)(void);
    void (*gw_engineer_finished_cb)(void);
    int  (*gw_fetch_local_log_cb)(char *path, int path_len);
    int  (*gw_led_state_changed_cb)(int state);
    int  (*gw_active_status_changed_cb)(const char *dev_id, int status);
    int  (*gw_online_status_changed_cb)(const char *dev_id, int status);	
} ty_gw_infra_cbs_s;

/**
 * @brief    initiate sdk.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_init(ty_gw_attr_s *attr, ty_gw_infra_cbs_s *cbs);

/**
 * @brief    unactive gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_unactive_gw(void);

/**
 * @brief    active gateway.
 *
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_active_gw(const char *token);

/**
 * @brief    allow or disallow subdevice to join network.
 *
 * @param permit. 0: disallow, 1: allow.
 * 
 * @retval   0: success
 * @retval  !0: failure
 */
int tuya_user_iot_permit_join(bool permit);

#ifdef __cplusplus
}
#endif
#endif // TUYA_GW_INFRA_API_H
